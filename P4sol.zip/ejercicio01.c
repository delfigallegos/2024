#include <stdio.h>
#include <assert.h>

void hola_hasta (int n);

int main()
{
    int n = 0;
    printf("Ingrese un valor numerico: ");
    scanf("%d",&n);
    if (n <0){
        printf(" EL numero debe ser positivo mayor que cero\n\n");
    }

    assert(n >0);
    
    hola_hasta(n);//ejecuto la funcion, imprime la cantidad de holas solicitada 
    return 0;
}


void hola_hasta (int n)
{
    while (n>0){
    printf ("Hola\n");
    n=(n-1);
    }
}

/*
void hola_hasta(int n)
{
    int contador=0;

    while (contador <n)
    {
        printf("Hola\n");
        contador+=1;
    }
    

}
*/