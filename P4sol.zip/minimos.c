#include <stdio.h>
#include <assert.h>
#include <limits.h>
#define N 5 //tamaño del arreglo

int minimo_pares(int tam, int a[]);
int minimo_impares(int tam, int a[]);

/*Estas funciones reciben un tamano maximo de arreglo y un arreglo como argumentos,
devolviendo el elemento par mas pequeno del arreglo y el elemento impar mas pequeno del
arreglo respectivamente.
En la funcion main se debe pedir al usuario los elementos del arreglo (asumiendo un
tama ̃no constante) y luego mostrar por pantalla:
-El resultado de minimo_pares(), para el arreglo ingresado
-El resultado de minimo_impares(), de nuevo, para el arreglo ingresado
-El elemento m ́ınimo del arreglo ingresado (utilizando el resultado de ambas funciones para calcularlo).
Pueden definir alguna funcion auxiliar si les resulta necesario.
NOTA: Investigar las constantes definidas en la librer ́ıa <limits.h> para definir el
neutro de la operaci ́on m ́ınimo
*/


int minimo_pares(int tam, int a[]){
    int posicion2;
    int minpar = INT_MAX;
    posicion2 = 0;

    while (posicion2 <= tam){
        if (a[posicion2]%2==0 && minpar>a[posicion2]){
            minpar=a[posicion2];  
            posicion2 = posicion2 + 1;
       }
        else 
        {
            posicion2 = posicion2 + 1;
        }
        
    }
    return minpar;
}

int minimo_impares(int tam, int a[]){
    int posicion;
    int minimpar= INT_MAX;
    posicion = 0;
    while ( posicion <= tam){
    if (a[posicion]%2!=0  && minimpar>a[posicion]){
        minimpar = a[posicion];
    } 
    posicion = posicion + 1;
}
    return minimpar;
}

int main (){
    int tam;
    printf ("Ingrese un tamaño maximo para su arreglo: ");
    scanf ("%d", &tam);

    int a[tam];

    for (int i = 0; i < tam; i++){
        printf ("Ingrese un entero para la posicion %d: ", i);
        scanf ("%d", &a[i]);
        }

        int minpar;
        minpar = minimo_pares (tam, a);
        printf ("El minimo par es: %d\n", minpar);

        int minimpar;
        minimpar = minimo_impares (tam, a);
        printf ("El minimo impar es: %d ", minimpar);

        return 0;
}