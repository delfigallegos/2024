#include <stdio.h>

int suma_hasta (int n) 
{
    if (n>=0) {
        int sumatoria = 0;

        for (int i=1; i<=n; i++) {
            sumatoria +=i;  //+= es un operador abreviado que significa "sumar y asignar". 
            //Es equivalente a escribir sumatoria = sumatoria + i;
        }
        return sumatoria;
    }
    else {
        printf ("ERROR! Ingrese un numero positivo");
        return -1;
    }

}

int main ()
{
    int n, resultado;

    printf ("Ingrese un numero natural\n");
    scanf ("%d",&n);

    resultado = suma_hasta (n);

    if (resultado !=-1){
    printf ("La sumatoria desde 1 hasta %d es: %d\n", n, resultado);
    }

    return 0;
}