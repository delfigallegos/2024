#include<stdio.h>
#include<assert.h>
#include<stdbool.h>

#define T 4

int fun10A(int i, int s, int A[]);
/**
 * | Estado | i  | s  |
 * | σ0     | -3 | 5  |
 * | σ10    | 0  | 0  |
 * | σ01    | 0  | 0  |
 * | σ02    | 1  | 2  |
 * | σ11    | 1  | 2  |
 * | σ12    | 2  | 12 |
 * | σ21    | 2  | 12 |
 * | σ22    | 3  | 22 |
 * | σ31    | 3  | 22 |
 * | σ32    | 4  | 21 |
 * | σ3     | 4  | 12 |
 *
 */

int fun10B(int i, int c, int A[]);
/**
 * | Estado | i | A.i | c  |
 * | σ0     | 3 | -   | 12 |
 * | σ10    | 0 | 12  |  1 |
 * | σ01    | 0 | 12  |  1 |
 * | σ02    | 1 | -9  |  1 |
 * | σ11    | 1 | -9  |  1 |
 * | σ12    | 2 | 10  |  1 |
 * | σ21    | 2 | 10  |  1 |
 * | σ22    | 3 | -1  |  2 |
 * | σ31    | 3 | -1  |  2 |
 * | σ32    | 4 | -   |  2 |
 * | σ3     | 4 | -   |  2 |
 */

int fun16B(int y, int N);

/**
 * Ejemplo de ejecucion:
 *  ******************** Traduccion del ej16 b) ********************
    Ingrese un valor entero para la variable Y:2
    Ingrese un valor entero para la variable n:0
    el resultado es:1
 *  ******************** Traduccion del ej16 b) ********************
    Ingrese un valor entero para la variable Y:5
    Ingrese un valor entero para la variable n:3
    el resultado es:125
 *  ******************** Traduccion del ej16 b) ********************
    Ingrese un valor entero para la variable Y:8
    Ingrese un valor entero para la variable n:-4
    Assertion failed: y = Y && N >= 0, file ej12.c, line 107
*/

/*void pedir_arreglo (int n_max, int a[]) {
    int posicion = 0;

    while (posicion < n_max) {
        printf("Introduzca el valor de la posicion %d: ", posicion);
        scanf("%d", &a[posicion]);
        posicion++;
    }
}
void imprimir_arreglo (int n_max, int a[]) {
    int posicion = 0;

    printf("[");

    // imprimo el primer elemento hasta el ante ultimo
    while (posicion < n_max - 1) {
        printf("%d, ", a[posicion]);
        posicion++;
    }

    printf("%d]\n", a[posicion]);
}
*/

void pedir_arreglo(int n_max, int a[])
{

    int i = 0;
    int valor = 0;
    while (i < n_max)
    {
        printf("Ingrese un valor para la posicion %d:", i);
        scanf("%d", &valor);
        a[i] = valor;
        valor = 0;
        i = i + 1;
    }
}

void imprimir_arreglo(int n_max, int a[])
{

    printf("[");
    int i = 0;
    while (i < (n_max - 1))
    {
        printf("%d,", a[i]);
        i = i + 1;
    }
    printf("%d]\n", a[n_max - 1]);
}

int pedirEntero (char name[]) {
    int n;

    printf ("Ingresa el valor del %s: ", name);
    scanf("%d", &n);

    return n;
}

/*int imprimeEntero (char name){
    int n = 0;
    
    printf("Ingrese un valor entero para la variable %c:", name);
    scanf("%d", &n);
    return n;
}*/
void imprimeEntero(char name, int x)
{
    printf("el valor de %c es :%d\n", name, x);
}


/*int main()
{
    int i, s, c, Y, N = 0;
    int arreglo[T];

    printf("  Traduccion del ej10 a)  \n");
    pedir_arreglo(T, arreglo);
    imprimir_arreglo(T, arreglo);
    i = pedirEntero('i');
    s = pedirEntero('s');
    s = fun10A(i, s, arreglo);
    imprimeEntero('s', s);
    printf("  Traduccion del ej10 b)  \n");
    i = pedirEntero('i');
    c = pedirEntero('c');
    pedir_arreglo(T, arreglo);
    imprimir_arreglo(T, arreglo);
    c = fun10B(i, c, arreglo);
    imprimeEntero('c', c);
    printf("  Traduccion del ej16 b)  \n");
    Y = pedirEntero('Y');
    N = pedirEntero('n');
    printf("el resultado es:%d", fun16B(Y, N));
    return 0;
}*/
int fun10A(int i, int s, int A[])
{

    i = 0;
    s = 0;
    while (i < T)
    {
        printf("antes asignacion -> i:%d,s:%d\n ", i, s);
        s = s + A[i];
        i = i + 1;
        printf("despues asignacion -> i:%d,s:%d\n", i, s);
    }
    return s;
}

int fun10B(int i, int c, int A[])
{
    i = 0;
    c = 0;
    while (i < T)
    {
        printf("antes asignacion -> i:%d,c:%d\n", i, c);
        if (A[i] > 0)
        {
            c = c + 1;
        }
        i = i + 1;
        printf("despues asignacion -> i:%d,c:%d\n", i, c);
    }

    return c;
}

int fun16B(int Y, int N)
{

    int x = 1;
    int y = Y;
    int n = 0;
    assert(y = Y && N >= 0);
    while (n != N)
    {
        x = x * y;
        n = n + 1;
    }
    assert(x = pow(Y, N));
    return x;
}