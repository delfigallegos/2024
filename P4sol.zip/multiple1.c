#include <stdio.h>

int main () 
{
    int x,y,z;
    //{Pre: x = X, y = Y}
    printf ("Ingresar un valor para X\n");
    scanf ("%d",&x);
    printf ("Ingresar un valor para Y\n");
    scanf ("%d",&y);

    z = x; //auxiliar para mantener el valor original de x
    x = x+1;
    y = z + y;
    printf ("Los nuevos valores son:\n X=%d , Y=%d", x, y); 
    //{Post: x -> X + 1, y -> X + Y}

    return 0;
}