#include <assert.h>
#include <stdio.h>

/*Escribir un programa en lenguaje C equivalente usando asignaciones simples teniendo en
cuenta que:
● Se deben verificar las pre y post condiciones usando la función assert().
● Los valores iniciales de x, y, z deben ser ingresados por el usuario
● Los valores finales de x, y, z deben mostrarse por pantalla usando la función
imprimir_entero del proyecto 3.
NOTA: Poner como comentario al menos un ejemplo de ejecución, con los parámetros de
entrada y la salida de tu programa (puedes hacer un copiar y pegar de la consola)*/

int pedir_entero(char letra) {
  int res;
  printf("Ingrese un valor para %c: ", letra);
  scanf("%d", &res);
  return res;
}

void imprime_entero(char letra, int entero) {
  printf("%c=%d\n", letra, entero);
}

int main(void) {
  int X, Y, Z;
  int x, y, z;
  X = pedir_entero('x');
  Y = pedir_entero('y');
  Z = pedir_entero('z');
  x = X;
  y = Y;
  z = Z;
  assert(x == X && y == Y && z == Z && Z % 2 != Y % 2);
  if (x % 2 == 0) {
    x = X + 1;
    y = Y + Z + Y;
    z = 2 * X;
  } else {
    x = X - 1;
    y = Y - Z - Y;
    z = 2 * X;
  }
  imprime_entero('x', x);
  imprime_entero('y', y);
  imprime_entero('z', z);
  assert(z == 2 * X &&
         ((x == X + 1 && y == Y + Z + Y) || (x == X - 1 && y == Y - Z - Y)));
  return 0;
}
//Ejercicio 3
/*que dado un tamaño de arreglo tam y un arreglo a[] devuelve una estructura struct
stonks, donde en el campo sube contará la cantidad de veces que a[i] <= a[i+1] para i en el
rango 0 <= i < tam-1, de manera análoga baja contará la cantidad de veces que a[i] > a[i+1]
para el mismo rango.
Por ejemplo: cuadro
Cabe aclarar que stonks_master() no debe mostrar ningún mensaje por pantalla ni
pedir valores al usuario.
En la función main se debe solicitar al usuario ingresar un arreglo de longitud N. Definir a
N como una constante, el usuario no debe elegir el tamaño del arreglo.
Finalmente desde la función main se debe mostrar el resultado de la función
stonks_master() por pantalla.
NOTA: Poner como comentario al menos un ejemplo de ejecución, con los parámetros de
entrada y la salida de tu programa (puedes hacer un copiar y pegar de la consola)
*/
#include <assert.h>
#include <stdio.h>
#include <stdbool.h>
#define N 5

char pedir_entero(void) {
  int res;
  scanf("%d", &res);
  return res;
}

void pedir_arreglo(int tam, int a[]) {
  int i = 0;
  while (i < tam) {
    printf("Ingrese elemento entero [%d/%d]: ", i + 1, tam);
    a[i] = pedir_entero();
    i = i + 1;
  }
}

struct stonks {
  int sube;
  int baja;
};

struct stonks stonks_master(int tam, int a[]) {
  int i = 0;
  struct stonks stks;
  assert(tam > 1);

  stks.sube = 0;
  stks.baja = 0;

  while (i < tam - 1) {
    if (a[i] <= a[i + 1]) {
      stks.sube = stks.sube + 1;
    } else {
      stks.baja = stks.baja + 1;
    }
    i = i + 1;
  }

  return stks;
}

int main(void) {
  int a[N];
  struct stonks stks;

  pedir_arreglo(N, a);
  stks = stonks_master(N, a);

  printf("sube: %d\n"
         "baja: %d\n",
         stks.sube, stks.baja);

  return 0;
}


/*Bien - El ejercicio tiene varios problemas que hacen que no funcione correctamente. * En la función struct stonks stonks_master(int tam, int a[]); no se contempla el caso en que el i’esimo elemento sea igual a i+1, entonces el arreglo [1, 1, 1] retorna subida=0 y bajada=0 * El bucle que estás ejecutando va entre 0 y tam, entonces va a comparar entre 0 y 2 en caso de tener un arreglo de 3 elementos, el tema es que como comparas entre i e i+i, cuando llegás al elemento 2, comparas con uno fuer adel areglo, resultando en un error.

y tiene 2 partes, la primera es la que vos preguntás, y es la menos grave de las dos. Si te fijas bien en el enunciado, en ese ejercicio te dice que si el número actual es menor al anterior entonces se considera que baja, en cambio si es mayor o igual, se considera que sube, y en el enunciado lo expresa así,
... donde en el campo sube contará la cantidad de veces que a[i] <= a[i+1] para i en el rango 0 <= i < tam-1, de manera análoga baja contará la cantidad de veces que a[i] > a[i+1] para el mismo rango.
 La segunda parte, y más grave, es que estás yéndote del rango del arreglo, y consultando valores fuera de él, y eso hace que tu algoritmo devuelva valores falsos.
A pesar de que estas dos correcciones son importantes, y que el ejercicio está mal implementado, consideré el ejercicio como B-, que eso te dio puntos para llegar a tu B-*/

//Ejercicio 4
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
/*Nuestra tarea será traducir determinado tipo de dato de la era Alonzo a la era Babbage. En
particular queremos traducir una componente central de Cardano el tipo output.
- Un output en Alonzo es básicamente un arreglo de int que solo puede tener
tamaño 2 o 3.
- Un output en Babbage, es una estructura más definida con 4 campos, uno de los
cuales puede no estar presente.(esto lo indica present)
En lo que respecta a nosotros podemos asumir que ambas versiones contienen la misma
información, solo que organizada de manera distinta. Puntualmente los tipos serán:
Para Alonzo, podremos simplemente declarar un arreglo de enteros de tamaño 2 o 3
(cualquier otro tamaño no tendrá sentido). Es decir, no hace falta un nuevo tipo y
podemos hacer simplemente: int a_output[2]; o int a_output[3]*/
typedef struct {
  int datum;
  bool present;
} maybe_datum;

typedef struct {
  int addr;
  int value;
  maybe_datum datum;
} babbage_output;

babbage_output alonzo_to_babbage(int tam, int a_output[]) {
  babbage_output b_out;
  maybe_datum nothing;

  assert(tam == 2 || tam == 3);

  nothing.datum = 0;
  nothing.present = false;

  b_out.addr = a_output[0];
  b_out.value = a_output[1];
  b_out.datum = nothing;

  if (tam == 3) {
    b_out.datum.datum = a_output[2];
    b_out.datum.present = true;
  }

  return b_out;
}

void print_babbage_output(babbage_output b_out) {

  printf("Address: %d\n", b_out.addr);
  printf("Value: %d\n", b_out.value);
  if (b_out.datum.present) {
    printf("Datum: %d\n", b_out.datum.datum);
  }
}

int main(void) {
  int a_output1[2] = {4242, 10};
  int a_output2[3] = {4243, 100, 5555};
  babbage_output b_out;

  b_out = alonzo_to_babbage(2, a_output1);
  print_babbage_output(b_out);

  b_out = alonzo_to_babbage(3, a_output2);
  print_babbage_output(b_out);

  return 0;
}