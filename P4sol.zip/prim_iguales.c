#include<stdio.h>
#include<assert.h>
#include<stdbool.h>
#define N 4 // tamaño del arreglo ("tamaño constante previamente establecido")

//int prim_iguales(int tam, int a[]);

/*que siendo tam el tamano del arreglo a[] devuelve la longitud del tramo inicial m ́as largo
cuyos elementos son todos iguales (parecida a la funci ́on primIguales del Proyecto 1).
a) En la funci ́on main se le debe pedir al usuario los elementos del arreglo asumiendo un
tama ̃no constante previamente establecido (en tiempo de compilaci ́on) y luego mostrar
el resultado de la funci ́on prim_iguales por pantalla*/

void imprimir_arreglo (int n_max, int a[]) {
    int posicion = 0;

    printf("[");

    while (posicion < n_max - 1) {
        printf("%d, ", a[posicion]);
        posicion++;
    }

    printf("%d]\n", a[posicion]);
}

int prim_iguales(int tam, int a[]){
    int longitudIguales = 0;
    int i = 0;
    while (i < tam){
        if (a[0] != a[i]){
            break;
        }
        longitudIguales = longitudIguales + 1;
        i = i + 1;
    }
    if (longitudIguales > 1){
        printf("el mayor tramo inicial del arreglo a[] que tiene a todos sus elementos iguales es: ");
        imprimir_arreglo(longitudIguales, a);
    }

    return longitudIguales;
}

int main () 
{
    // pido al usuario el tamaño del arreglo
    int tam = printf("Ingrese el tamaño del arreglo: ");
    scanf("%d", &tam);

    // verifico que el valor sea valido
    assert(tam > 0 && "El tamaño del arreglo debe ser mayor o igual a 1");

    // declaro el arreglo con el tamaño deseado
    int a[tam];

    // pido al usuario los valores del arreglo
    for (int i = 0; i < tam; i++) {
        printf("Ingrese el valor de la posicion %i: ", i);
        scanf("%d", &a[i]);
    }
    
    // imprimo el arreglo por pantalla
    printf("El arreglo ingresado es [");
    for (int i = 0; i < tam-1; i++) {
        printf("%d, ", a[i]);
    }
    printf("%d]\n", a[tam-1]);

    // ejecuto el programa
    int res = prim_iguales(tam, a);
    printf("La longitud del tramo inicial mas largo cuyos elementos son iguales es %d\n", res);
    
    // punto estrella
    printf("El arreglo con el primer tramo de numeros iguales es [");
    for (int i = 0; i < res-1; i++) {
        printf("%d, ", a[i]);
    }
    printf("%d]\n", a[res-1]);

    return 0;
}
