#include <stdio.h>
#include <assert.h>
#include <math.h>
#define T 4

int fun10A(int i, int s, int A[]);

int fun10B(int i, int c, int A[]);

int fun16B(int y, int N);

//funciones auxiliares
void pedir_arreglo(int n_max, int a[])
{
    int i = 0;
    int valor = 0;
    while (i < n_max)
    {
        printf("Ingrese un valor para la posicion %d: ", i);
        scanf("%d", &valor);
        a[i] = valor;
        valor = 0;
        i = i + 1;
    }
}

void imprimir_arreglo(int n_max, int a[])
{

    printf("[");
    int i = 0;
    while (i < (n_max - 1))
    {
        printf("%d,", a[i]);
        i = i + 1;
    }
    printf("%d]\n", a[n_max - 1]);
}

int pedirEntero(char name)
{
    int n = 0;

    printf("Ingrese un valor entero para la variable %c: ", name);
    scanf("%d", &n);
    return n;
}

void imprimeEntero(char name, int x)
{
    printf("el valor de %c es: %d\n", name, x);
}


int main()
{
    int i, s, c, Y, N = 0;
    int arreglo[T];

    printf(" ~ Traduccion del ej10 a) ~ \n");
    pedir_arreglo(T, arreglo);
    imprimir_arreglo(T, arreglo);
    i = pedirEntero('i');
    s = pedirEntero('s');
    s = fun10A(i, s, arreglo);
    imprimeEntero('s', s);
    printf(" ~ Traduccion del ej10 b) ~ \n");
    i = pedirEntero('i');
    c = pedirEntero('c');
    pedir_arreglo(T, arreglo);
    imprimir_arreglo(T, arreglo);
    c = fun10B(i, c, arreglo);
    imprimeEntero('c', c);
    printf(" ~ Traduccion del ej16 b) ~ \n");
    Y = pedirEntero('Y');
    N = pedirEntero('n');
    printf("el resultado es: %d", fun16B(Y, N));
    return 0;
}

int fun10A(int i, int s, int A[])
{

    i = 0;
    s = 0;
    while (i < T)
    {
        printf("antes asignacion: i:%d, s:%d\n ", i, s);
        s = s + A[i];
        i = i + 1;
        printf("despues asignacion: i:%d, s:%d\n", i, s);
    }
    return s;
}

int fun10B(int i, int c, int A[])
{
    i = 0;
    c = 0;
    while (i < T)
    {
        printf("antes asignacion: i:%d, c:%d\n", i, c);
        if (A[i] > 0)
        {
            c = c + 1;
        }
        i = i + 1;
        printf("despues asignacion: i:%d, c:%d\n", i, c);
    }

    return c;
}

int fun16B(int Y, int N)
{

    int x = 1;
    int y = Y;
    int n = 0;
    assert(y = Y && N >= 0);
    while (n != N)
    {
        x = x * y;
        n = n + 1;
    }
    assert(x = pow(Y, N));
    return x;
}