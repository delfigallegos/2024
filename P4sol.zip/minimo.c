#include<stdio.h>
#include<assert.h>

int minimo (int x, int y)
{
    if (x>y)
    {
        printf("El entero menor es: %d", y);
        return y;
    }
    else
    {
        printf("El entero menor es: %d", x);
        return x;
    }
    
}

int main()
{
    int x, y = 0;

    printf("ingrese un entero X\n");
    scanf("%d",&x);
    printf("ingrese un valor entero Y distinto de X\n");
    scanf("%d",&y);

    assert (x!=y);

    minimo (x,y);

    return 0;
}