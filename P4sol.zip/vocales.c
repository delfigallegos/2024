#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
/*
bool es_vocal(char letra);

char pedir_Char(char name);

int main(){
    char l;
    l = pedir_Char('L');

    printf (" la letra %c es (1=Vocal, 0=Constante):%d", l, es_vocal(l));
    return 0;
}

char pedir_Char(char name){
    char n= 'S';
    printf("Ingrese un valor char para la variable %c: ", name); 
    // lo que hace es recibir un char como parametro, y asi decir que ése es el nombre de la variable que va a almacenar el valor, pero puede serlo, como puede llamarse de otra forma y el mensaje no cambiaría a menos que le pasemos otro char como parámetro.
    scanf("%c", &n);
    return n;
}

bool es_vocal(char letra){

    char vocal[10]="aeiouAEIOU";
    int n= 0;
    while (n<10)
    {
        if (letra==vocal[n])
        {
            return true;
        }
        n=n+1;
    }
    
    return false;
}*/


/*
char pedir_letra () {
    char c;

    printf("Introduce una letra: ");
    scanf("%c", &c);

    return c;
}

bool es_vocal (char letra) {
    bool res = letra == 'a' || letra == 'e' || letra == 'i' || letra == 'o' || letra == 'u';

    return res;
}

int main () {

    // verifico si la letra introducida por el usuario es vocal
    bool res = es_vocal(pedir_letra());

    // imprimo el resultado
    res ? 
        printf("La letra introducida es vocal\n"):
        printf("La letra introducida NO es vocal\n");

    return 0;
}
*/


bool es_vocal(char letra){

    //char vocal[10]="aeiouAEIOU";
    //if (letra==vocal[10]){
    if (letra== 'a' ||letra== 'i' ||letra== 'e' ||letra== 'o' ||letra== 'u' ||letra== 'A' ||letra== 'E' ||letra== 'I' ||letra== 'O' ||letra== 'U' ){
    printf ("'%c' ES UNA VOCAL\n",letra);
    return true;
    }
    
    else {
    printf ("'%c' NO ES UNA VOCAL\n",letra);
    return false;
    }
}

int main () {
    char letra;
    printf ("INGRESE UNA LETRA: ");
    scanf ("%c",&letra);

    es_vocal (letra);
    return 0;
}


