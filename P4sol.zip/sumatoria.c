#include <stdio.h>
#include <assert.h>

/*que recibe un tamano maximo de arreglo y un arreglo como argumento, y devuelve la suma de sus elementos
En la funcion main pedir los datos del arreglo al usuario*/

/*int pedirEntero (char name)
{
    int n=0;
    printf("ingrese el entero positivo q sera la longitud del arreglo %c: ", name);
    scanf("%d",&n);
    return n;
}*/

void pedir_arreglo (int n_max, int a[]) {
    int posicion = 0;

    while (posicion < n_max) {
        printf("Introduzca el valor de la posicion %d: ", posicion);
        scanf("%d", &a[posicion]);
        posicion++;
    }
}

void imprimir_arreglo (int n_max, int a[]) {
    int posicion = 0;

    printf("[");

    while (posicion < n_max - 1) {
        printf("%d, ", a[posicion]);
        posicion++;
    }

    printf("%d]\n", a[posicion]);
}

int sumatoria(int tam, int a[])
{

    int res = 0;
    int i = 0;
    while (i < tam)
    {
        res = res + a[i];
        i = i + 1;
    }

    return res;
}
int main()
{
    int tam, resultado = 0;
    printf ("Ingrese un tamaño maximo para su arreglo: ");
    scanf ("%d",&tam);
    //tam = pedirEntero('A');
    assert(tam > 0);
    int arreglo[tam];
    pedir_arreglo(tam, arreglo);
    resultado = sumatoria(tam, arreglo);
    imprimir_arreglo(tam, arreglo);
    printf("El resultado de la suma de todos los elementos es : %d", resultado);

    return 0;
}


