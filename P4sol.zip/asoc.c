#include<stdio.h>
#include <assert.h>
#include <stdbool.h>
#define N 5

/*bool asoc_existe(int tam, struct asoc a[], clave_t c)
{
 
}

typedef char clave_t;
typedef int valor_t;

struct asoc {
clave_t clave;
valor_t valor;
};
El llamado a asoc_existe(tam, a, c) debe indicar si la clave c se encuentra en el arreglo
de asociaciones a[]. En la funcion main pedir al usuario los datos del arreglo y luego pedir una clave. 
Finalmente usar la funci ́on asoc_existe para verificar la existencia de la clave ingresada 
y mostrar por pantalla un mensaje indicando si la
clave existe o no en el arreglo de asociaciones.*/

typedef char clave_t;
typedef int valor_t;


struct asoc {
    clave_t clave;
    valor_t valor;
};

bool asoc_existe (int tam, struct asoc a[], clave_t c) {
    //bool res = false;
    int i = 0;
    while (i < tam)
    {
        if (a[i].clave == c)
        {
            return true;
        }
        i = i + 1;
    }

    /*
    
    for (int i = 0; i < tam && !res; i++) {
        if (a[i].clave == c) {
            res = true;
        }
    }*/
    
    return false;
}

int main () {


    // declaro el arreglo con la longitud deseada
    struct asoc a[N];
    int tam= N;

    // pido al usuario los valores del arreglo, que en éste caso serán estructuras
    for (int i = 0; i < tam; i++) {
        //printf("Ingrese la clave y el valor de la posicion %d:\n", i);
        printf("Clave: ");
        scanf(" %c", &a[i].clave); // sin el espacio no lee la clave
        printf("Valor: ");
        scanf("%d", &a[i].valor);
    }

    // imprimo el arreglo
    printf("[");
    for (int i = 0; i < tam-1; i++) {
        printf("(%c,%d), ", a[i].clave, a[i].valor);
    }
    printf("(%c,%d)]\n", a[tam-1].clave, a[tam-1].valor);

    // pido la clave que vamos a buscar
    char c = printf("Ingrese la clave a buscar: ");
    scanf(" %c", &c);

    // ejecuto la funcion pedida e imprimo el resultado
    bool res = asoc_existe(tam, a, c);
    res ? printf("La clave existe en el arreglo\n") : printf("La clave NO existe en el arreglo\n");

    return 0;
}
