#include <stdio.h>

int main () 
{ 
    //{Pre: x = X, y = Y, z = Z}
    int x,y,z,a,b,c;

    printf ("Indrese un valor para X\n");
    scanf ("%d",&x);
    printf ("Indrese un valor para Y\n");
    scanf ("%d",&y);
     printf ("Indrese un valor para Z\n");
    scanf ("%d",&z);

    a=z;
    b=x;
    c=y;

    x = c;
    y = a+b+c;
    z = c+b;
    
    printf ("Los nuevos valores son: X=%d, Y=%d, Z=%d\n", x, y,z); 
    //{Post: x = Y, y = Y + X + Z, z = Y + X}

    return 0;
}