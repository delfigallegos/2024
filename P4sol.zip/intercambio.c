#include<stdio.h>

int main()
{
    int x,y,z=0;
    printf("Ingrese un valor para X\n");
    scanf("%d", &x);
    printf("Ingrese un valor para Y\n");
    scanf("%d", &y);
//(z es una variable auxiliar que se usa para guardar el valor de x, antes de modificarla)
    z = x;
    x = y;
    y = z;
    printf("Realizado el intercambio, estos son los nuevos valores:\nX=%d , Y=%d", x, y);

    return 0;
}

