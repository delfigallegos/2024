#include<stdio.h>

/*
σ0 :(x → 5 , y → 4, z → 8, m → 0)
    var x,y,z,m:Int;
    if (x < y) → m := x
    (x ≥ y)    → m := y
    fi 
σ1 :(x → 5 , y → 4, z → 8, m → 4)
    if (m < z) → skip
    (m ≥ z)    → m := z
    fi
σ2 :(x → 5 , y → 4, z → 8, m → 4) 
*/


int main(){

    // Instanciacion de Variables
    int x = 0;
    int y = 0;
    int z = 0;
    int m = 0;

    // Solicitud de ingreso de valores para las variables.
    printf("Ingrese un valor numerico para x: ");
    scanf("%d", &x);
    printf("Ingrese un valor numerico para y: ");
    scanf("%d", &y);
    printf("Ingrese un valor numerico para z: ");
    scanf("%d", &z);
    printf("Ingrese un valor numerico para m: ");
    scanf("%d", &m);

    // Comprobación de Valores de x e y
    if (x < y)
    {
        m = x;

    }else
    {
        m = y;
    }

    if (m < z)
    {
        m = m;
        z = z;
        
    }else
    {
        z = m;
    }

    // Visualizacion de los estados finales de las variables
    printf("El estado de x es %d, el de y es %d, el de z es %d y el de m es %d.\n\n ", x, y, z, m);
    printf("El valor final de m es: %d\n\n ", m);

    return 0;
}