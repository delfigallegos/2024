#include <stdio.h>

// Definicion de Prototipos
void imprimeHola(void);
void imprimeChau(void);


int main()
{
    imprimeHola();
    imprimeChau();
    return 0;
}

void imprimeHola(void)
{
    printf("Hola\n");
    printf("Hola\n");
}

void imprimeChau(void)
{
    printf("Chau\n");
    printf("Chau\n");
}
