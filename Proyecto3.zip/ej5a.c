#include <stdio.h>

int main()
{
    // Tracuccion del 1.h)
    printf(" --Tracuccion del Ej1.h--\n");

    // Instanciacion de variables
    int i = 0;
    // Peticion de ingreso de valores
    printf(" Ingrese el valor de i: ");
    scanf("%d", &i);
    printf("\n");

    while (i != 0)
    {
        i = i - 1;

        // Visualizacion del estado de la variable en cada iteración.
        printf(" El valor de i es %d\n", i);
    }
    printf("\n");

/*
 --Tracuccion del Ej1.h--
 Ingrese el valor de i: 4

 El valor de i es 3
 El valor de i es 2
 El valor de i es 1
 El valor de i es 0
*/

    // Tracuccion del 1.i)
    printf(" --Tracuccion del Ej1.i) --\n");

    // Reseteo de valores para la variable.
    i = 0;

    // Peticion de ingreso de valores.
    printf(" Ingrese el valor de i: ");
    scanf("%d", &i);

    while (i != 0)
    {
        i = 0;

        // Visualizacion del estado de la variable.
        printf(" El valor de i es %d\n\n", i);
        return 0;
    }

    // Visualizacion del estado final de la variable.
    printf(" El valor de i es %d\n\n", i);
/*
 --Tracuccion del Ej1.i) --
 Ingrese el valor de i: 400
 El valor de i es 0
*/
    return 0;
}