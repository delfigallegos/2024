#include<stdio.h>
/*
    Se define antes del main para indicar al compilador que existe una función llamada pedirEntero que será utilizada más adelante en el código.
    Esta técnica se llama declaración anticipada o prototipo de función, para que el compilador sepa qué tipo de datos devuelve la función y qué tipo de argumentos espera antes de que la función sea realmente definida más adelante en el código.
 */

// Prototipo de las funciones a definir

int pedirEntero(char name);
void imprimirEntero(char name, int x);

int main(void)
{
    // Instanciacion de Variables
    int pideEntero = 0;
    char texto = 't';

    printf("Ingrese una letra: ");
    scanf("%c", &texto);

    // Llamado a las funciones
    pideEntero = pedirEntero(texto);
    imprimirEntero(texto, pideEntero);
    return 0;
}

// Funciones ya definidas
int pedirEntero(char name)
{
    int n = 0;
    printf("Ingrese el entero para la variable %c: ", name); 
    // lo que hace es recibir un char como parametro, y asi decir que ése es el nombre de la variable que va a almacenar el valor, pero puede serlo, como puede llamarse de otra forma y el mensaje no cambiariía a menos que le pasemos otro char como parámetro.
    scanf("%d", &n);
    return n;
}

void imprimirEntero(char name, int x)
{
    printf("el valor de %c es: %d\n", name, x);
}

int pedir_entero(void);

void imprimir_entero(int x);

/*
Ingrese una letra: p
Ingrese el entero para la variable p: 10
el valor de p es: 10

Usuario@DESKTOP-75O6O40 MINGW64 ~/Desktop/2024/Proyecto3 (main)
$ ./prueba6
Ingrese una letra: d
Ingrese el entero para la variable d: 20
el valor de d es: 20
*/