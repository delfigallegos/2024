#include <stdio.h>
#include <stdbool.h>

/* Prototipos */
bool pedirBooleano(char name);
void imprimirBool(char name,bool x);


int main(){
    char texto='t';
    printf("Ingrese una letra: ");
    scanf("%c", &texto);

    imprimirBool(texto,pedirBooleano(texto));
    return 0;
}


// Definición de Pedir Booleano 
bool pedirBooleano(char name)
{
    int x=0;
    printf("Ingrese 1 para True o 0 para False para agregar en la variable %c: ",name);
    scanf("%d", &x);
    if (x>1){
        printf("Ingresaste un valor mayor a 1 \n-Se definio como 1 la opcion que elegiste-\n");
        x=1;
    }else if(x<0){
        printf("Ingresaste un valor menor a 0 \n-Se definio como 0 la opcion que elegiste-\n");
        x=0;

    }
    return x;
}

// Definición de Imprime Booleano 
void imprimirBool(char name, bool x){
    if(x==1)
    {
        printf("%c: verdadero\n\n",name);
    }
    else
    {
        printf("%c: falso\n\n",name);

    }
}
/*
Ingrese una letra: t
Ingrese 1 para True o 0 para False para agregar en la variable t: 1
t: verdadero

Ingrese una letra: r
Ingrese 1 para True o 0 para False para agregar en la variable r: -1
Ingresaste un valor menor a 0 
-Se definio como 0 la opcion que elegiste-
r: falso
*/