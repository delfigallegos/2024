#include <stdio.h>

/*
Escribi el programa del ejercicio 4b, pero utilizando las funciones del ejercicio anterior.
¿Que ventajas encontras en esta nueva version?. ¿Podrıas escribir alguna otra funcion
en ese ejercicio, cual?. ¿En que otros ejercicios de ese Proyecto lo podrıas utilizar?.
Reescribı los programas donde puedas utilizarlas.
*/

/* Reescritura del Ejericicio 4.B con funciones. */
#include<stdio.h>
#include<stdbool.h>


int pedirEntero(char name)
{
    int n=0;
    printf("Ingrese un valor para la variable %c: ",name);
    scanf("%d",&n);
    return n;

}
  
void imprimirEntero(char name,int x)
{

printf("El valor de la variable %c es: %d\n",name,x);
}

int main()
{
    
    int x=pedirEntero('x');
    int y=pedirEntero('y');
    int z=pedirEntero('z');
    int m=pedirEntero('m');
   
    if (x<y)
    {
        m=x;
    }
    else 
    {
       m=y;
    }
    imprimirEntero('x',x);
    imprimirEntero('y',y);
    imprimirEntero('z',z);
    imprimirEntero('m',m);

    if (m<z)
    {
        m=m;
        z=z;
    }
    else
    {
        m=z;
    }
    imprimirEntero('x',x);
    imprimirEntero('y',y);
    imprimirEntero('z',z);
    imprimirEntero('m',m);
    return 0;
}
    /*
     se evita el codigo repetitivo y se optimiza el tiempo de escritura
    lo podrías utilizarse en los ejercicios 2,3,4 y 5
    */
    
