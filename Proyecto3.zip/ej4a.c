#include<stdio.h>

int main()
{
    // inicializacion de variables
    int x = 0;
    int y = 0;

    // Traduccion 1.e)
    printf(" --TRADUCCION EJERCICIO 1.E-- \n");
    
    printf(" Asigne un numero a x: ");
    scanf("%d",&x);
    printf(" Asigne un numero a y: ");
    scanf("%d",&y);
    if (x>=y)
    {
        x=0;
    }
    else if (x<=y)
    {
        x=2;
    }
    printf(" El valor de x es: %d\n El valor de y es: %d\n\n", x,y);

/* 
--TRADUCCION EJERCICIO 1.E-- 
 Asigne un numero a x: 3
 Asigne un numero a y: 1
 El valor de x es: 0
 El valor de y es: 1

--TRADUCCION EJERCICIO 1.E-- 
 Asigne un numero a x: 1
 Asigne un numero a y: 3
 El valor de x es: 2
 El valor de y es: 3
 */

   // Traduccion 1.f)
    printf(" --TRADUCCION EJERCICIO 1.F-- \n");
    
    printf(" Asigne un numero a x: ");
    scanf("%d",&x);
    printf(" Asigne un numero a y: ");
    scanf("%d",&y);

    if (x>=y)
    {
        x=0;
    }
    else if (x<=y)
    {
        x=2;
    }
    printf(" El valor de x es: %d y El valor de y es: %d", x,y);

    /* 
     --TRADUCCION EJERCICIO 1.F--
     Asigne un numero a x: -100
     Asigne un numero a y: 1
     El valor de x es: 2 y El valor de y es: 1

    --TRADUCCION EJERCICIO 1.F--
       Asigne un numero a x: 5
       Asigne un numero a y: 2
       El valor de x es: 0 y El valor de y es: 2 
    */
    return 0;
}
