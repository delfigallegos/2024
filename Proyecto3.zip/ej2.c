#include <stdio.h>
#include <stdbool.h>

/*
Encontra los valores para la variables q forman el estado cumpliendo con q las expresiones tengan el valor indicado

(x → 0, y→ 0, z→ 0, b→ 0, w→ 0)

|Expresion                        | Valor
----------------------------------------
| x % 4 == 0                      |True
| x + y == 0 && y - x == (-1) * z |True
| not b && w                      |False
*/

char * comprobacion(int expresion)
{
    if ((expresion) == 1)
    {
        return "True";
    }
    return "False";
}

int main()
{
    // Inicializacion de Variables
    int x = 0;
    int y = 0;
    int z = 0;
    int b = 0;
    int w = 0;
    
    // Expresiones Solicictadas
    printf("Resultado de %d (Modulo)4 == 0 es %s\n",x,comprobacion((x%4==0)));
    printf("Resultado de %d + %d == 0 && %d - %d == (-1) * %d es : %s\n",x,y,y,x,z,comprobacion((x+y == 0 && y -x == (-1) * z)));
    printf("Resultado de not %d && %d es: %s\n",b,w,comprobacion((!b && w)));

/*
Resultado de 0 (Modulo)4 == 0 es True
Resultado de 0 + 0 == 0 && 0 - 0 == (-1) * 0 es : True
Resultado de not 0 && 0 es: False
*/

    return 0;
}
